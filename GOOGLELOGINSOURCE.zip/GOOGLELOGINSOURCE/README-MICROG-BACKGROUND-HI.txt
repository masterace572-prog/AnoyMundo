MICROG BACKGROUND INSTALL

MicroG download/install ko UI thread par directly call na karein.
Use:

MicroGInstaller.installMicroGInBackground(
    context,
    (file, downloaded, total) -> {
        // Progress callback main/UI thread par aata hai.
    },
    result -> {
        // Completion callback main/UI thread par aata hai.
        // result mein success ya failure message hota hai.
    }
);

GoogleServicesInstaller.java mein required Meta imports bhi included hain.
MicroG install ke baad user ko Google Software Settings mein sign in,
device registration enable, aur game restart karna hoga.
