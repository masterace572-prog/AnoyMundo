package com.xlox;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;


// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL

/** Full-screen black backdrop with the restrained floating particles used by the UI reference. */
public class ProAnimatedBackground extends View {
    private static final int PARTICLE_COUNT = 58;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(20261121L);
    private final float[] x = new float[PARTICLE_COUNT];
    private final float[] y = new float[PARTICLE_COUNT];
    private final float[] radius = new float[PARTICLE_COUNT];
    private final float[] speed = new float[PARTICLE_COUNT];
    private final float[] drift = new float[PARTICLE_COUNT];
    private final int[] colors = new int[PARTICLE_COUNT];
    private float phase;
    private boolean running = true;

    public ProAnimatedBackground(Context context) {
        super(context);
        initialize();
    }

    public ProAnimatedBackground(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public ProAnimatedBackground(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    private void initialize() {
        paint.setStyle(Paint.Style.FILL);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private void seedParticles(float width, float height) {
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            x[i] = random.nextFloat() * width;
            y[i] = random.nextFloat() * height;
            radius[i] = 1.2f + random.nextFloat() * 3.4f;
            speed[i] = 0.18f + random.nextFloat() * 0.65f;
            drift[i] = -0.28f + random.nextFloat() * 0.56f;
            int choice = random.nextInt(10);
            colors[i] = choice < 5 ? Color.rgb(236, 238, 241)
                    : (choice < 8 ? Color.rgb(205, 25, 34) : Color.rgb(113, 23, 28));
        }
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        seedParticles(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        canvas.drawColor(Color.BLACK);
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            y[i] += speed[i];
            x[i] += drift[i] + (float) Math.sin((phase + i) * 0.07f) * 0.08f;
            if (y[i] > height + radius[i] * 2) {
                y[i] = -radius[i] * 2;
                x[i] = random.nextFloat() * width;
            }
            if (x[i] < -8) x[i] = width + 8;
            if (x[i] > width + 8) x[i] = -8;
            paint.setColor(colors[i]);
            paint.setAlpha(105 + (i % 4) * 35);
            canvas.drawCircle(x[i], y[i], radius[i], paint);
        }
        paint.setAlpha(255);
        phase += 1f;
        if (running) postInvalidateOnAnimation();
    }

    public void pauseAnimation() {
        running = false;
    }

    public void resumeAnimation() {
        running = true;
        postInvalidateOnAnimation();
    }
}
// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL
// @DEVIL_VIP_DEVIL