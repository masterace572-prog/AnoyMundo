package com.xlox;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.xlox.utils.AppManager;
import com.xlox.utils.Downtwo;
import com.xlox.utils.GoogleServicesInstaller;
import com.xlox.utils.MicroGInstaller;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import net_62v.external.MetaActivationManager;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaStorageManager;

@Obfuscate
public class MAct extends AppCompatActivity {

    private static native String exdate();

    static {
        try {
            System.loadLibrary("DEVIL");
        } catch (UnsatisfiedLinkError ignored) {}
    }

    private static final String PKG_BGMI = "com.pubg.imobile";
    private static final String PREF_NAME = "com.xlox.download";
    private static final String PREF_VERSION_KEY = "version";

    // UI
    private ProgressBar downloadProgressBar;
    private TextView downloadStatusText;
    private TextView percentText;
    private View downloadBox;
    private View restartButton;
    private ProgressBar loadingCursor;
    private TextView appVersionText;
    
    private TextView startText;
    private ImageView actionIcon;
    private View startBgmi;
    private View startFB;
    private View fbCard;
    private View settingsTile, logsTile, updateTile, logoutTile, settingsButton;
    private View statusToggle;
    private View statusLoader;
    private ImageView statusErrorIcon;
    private TextView statusToggleText;

    private TextView gameName;
    private TextView packageName;
    private TextView gameStatus;
    private TextView subscriptionStatus;
    private TextView expiryValue;
    private TextView timeRemaining;
    private TextView deviceValue;
    private TextView deviceStatus;

    private TextView daysValue;
    private TextView hoursValue;
    private TextView minutesValue;
    private TextView secondsValue;

    private View obbButton;
    private boolean isObbCopied = false;
    private boolean isGameRunning = false;
    private boolean isGameInstalled = false;
    private boolean isUpdateAvailable = false;
    private boolean googleServicesSetupRunning = false;
    private ProAnimatedBackground proAnimatedBackground;

    private void setupMainBackgroundAnimation() {
        proAnimatedBackground = findViewById(R.id.proAnimatedBackground);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (proAnimatedBackground != null) proAnimatedBackground.resumeAnimation();
    }

    @Override
    protected void onPause() {
        if (proAnimatedBackground != null) proAnimatedBackground.pauseAnimation();
        super.onPause();
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#05060A"));
            getWindow().setNavigationBarColor(Color.parseColor("#05060A"));
            int systemUiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            getWindow().getDecorView().setSystemUiVisibility(systemUiFlags);
        }

        setContentView(R.layout.activity_main);
        setupMainBackgroundAnimation();

        checkPermissions();

        // Download UI
        downloadBox = findViewById(R.id.downloadBox);
        downloadProgressBar = findViewById(R.id.downloadProgressBar);
        downloadStatusText = findViewById(R.id.downloadStatusText);
        percentText = findViewById(R.id.percentText);
        restartButton = findViewById(R.id.restartButton);
        loadingCursor = findViewById(R.id.loadingCursor);
        appVersionText = findViewById(R.id.appVersionText);

        // Action UI
        startText = findViewById(R.id.startText);
        actionIcon = findViewById(R.id.actionIcon);
        startBgmi = findViewById(R.id.startBgmi);
        startFB = findViewById(R.id.startFB);
        fbCard = findViewById(R.id.fbCard);
        settingsTile = findViewById(R.id.settingsTile);
        logsTile = findViewById(R.id.logsTile);
        updateTile = findViewById(R.id.updateTile);
        logoutTile = findViewById(R.id.logoutTile);
        settingsButton = findViewById(R.id.settingsButton);

        gameName = findViewById(R.id.gameName);
        packageName = findViewById(R.id.packageName);
        gameStatus = findViewById(R.id.gameStatus);
        statusToggle = findViewById(R.id.statusToggle);
        statusLoader = findViewById(R.id.statusLoader);
        statusErrorIcon = findViewById(R.id.statusErrorIcon);
        statusToggleText = findViewById(R.id.statusToggleText);
        subscriptionStatus = findViewById(R.id.subscriptionStatus);
        expiryValue = findViewById(R.id.expiryValue);
        timeRemaining = findViewById(R.id.timeRemaining);
        deviceValue = findViewById(R.id.deviceValue);
        deviceStatus = findViewById(R.id.deviceStatus);
        if (deviceValue != null) {
            deviceValue.setText(Build.MODEL == null ? "Android device" : Build.MODEL);
        }

        obbButton = findViewById(R.id.obbButton);

        daysValue = findViewById(R.id.daysBox).findViewById(R.id.timeValue);
        hoursValue = findViewById(R.id.hoursBox).findViewById(R.id.timeValue);
        minutesValue = findViewById(R.id.minutesBox).findViewById(R.id.timeValue);
        secondsValue = findViewById(R.id.secondsBox).findViewById(R.id.timeValue);
        ((TextView) findViewById(R.id.daysBox).findViewById(R.id.timeLabel)).setText("DAYS");
        ((TextView) findViewById(R.id.hoursBox).findViewById(R.id.timeLabel)).setText("HOURS");
        ((TextView) findViewById(R.id.minutesBox).findViewById(R.id.timeLabel)).setText("MINUTES");
        ((TextView) findViewById(R.id.secondsBox).findViewById(R.id.timeLabel)).setText("SECONDS");
        setKeyTimeUnavailable();
        startKeyCountdown();
        startPageAnimation();

        checkObbApplied();
        updateGameStatus();
        updateVersionDisplay();
        checkForRemoteUpdate();
        ensureGoogleServices();
        applySavedTheme();
        View licenseCard = findViewById(R.id.mainCard);
        if (licenseCard != null) licenseCard.setOnClickListener(v -> showLicenseDetails());

        if (obbButton != null) {
            obbButton.setOnClickListener(v -> openExternalUrl("https://www.facebook.com/"));
        }

        if (restartButton != null) {
            restartButton.setOnClickListener(v -> restartApp());
        }

        if (startBgmi != null) {
            startBgmi.setOnClickListener(v -> {
                if (isUpdateAvailable) {
                    startDownload();
                } else if (!isGameInstalled) {
                    installGame();
                } else if (isGameRunning) {
                    stopGame();
                } else {
                    handleLaunchFlow();
                }
            });
        }

        if (startFB != null) {
            startFB.setOnClickListener(v -> openExternalUrl("https://www.facebook.com/"));
        }
        View facebookIcon = findViewById(R.id.facebookIcon);
        if (facebookIcon != null) {
            facebookIcon.setOnClickListener(v -> openExternalUrl("https://www.facebook.com/"));
        }
        View twitterText = findViewById(R.id.startTwitter);
        if (twitterText != null) {
            twitterText.setOnClickListener(v -> openExternalUrl("https://twitter.com/"));
        }
        View twitterIcon = findViewById(R.id.twitterIcon);
        if (twitterIcon != null) {
            twitterIcon.setOnClickListener(v -> openExternalUrl("https://twitter.com/"));
        }
        View.OnClickListener settingsAction = v -> showSettingsDialog();
        View.OnClickListener logsAction = v -> showInfoDialog("Logs", "No new errors were found.");
        View.OnClickListener updateAction = v -> showInfoDialog("Check Update", "You are using the latest version.");
        if (settingsTile != null) settingsTile.setOnClickListener(settingsAction);
        if (settingsButton != null) settingsButton.setOnClickListener(settingsAction);
        if (logsTile != null) logsTile.setOnClickListener(logsAction);
        if (updateTile != null) updateTile.setOnClickListener(updateAction);
        if (logoutTile != null) logoutTile.setOnClickListener(v -> logoutUser());

        // Start Workflow: Update Check -> Download Files (if needed)
        startWorkflow();
    }

    private void startPageAnimation() {
        View logoGlow = findViewById(R.id.logoGlow);
        View mainLogo = findViewById(R.id.mainLogo);
        if (mainLogo != null) {
            ObjectAnimator logoFloat = ObjectAnimator.ofFloat(mainLogo, View.TRANSLATION_Y, 0f, -6f, 0f);
            logoFloat.setDuration(2600);
            logoFloat.setRepeatCount(ObjectAnimator.INFINITE);
            logoFloat.start();
        }
        if (logoGlow != null) {
            ObjectAnimator glowRotation = ObjectAnimator.ofFloat(logoGlow, View.ROTATION, 0f, 360f);
            glowRotation.setDuration(7000);
            glowRotation.setInterpolator(new LinearInterpolator());
            glowRotation.setRepeatCount(ObjectAnimator.INFINITE);
            glowRotation.start();
            logoGlow.animate().translationY(-5f).setDuration(1300)
                    .withEndAction(() -> logoGlow.animate().translationY(0f).setDuration(1300).start()).start();
        }
        View[] views = {findViewById(R.id.brandHeader), findViewById(R.id.mainCard),
                findViewById(R.id.statusToggle), findViewById(R.id.keyTimeRow), findViewById(R.id.fbCard)};
        long delay = 0;
        for (View view : views) {
            if (view != null) {
                view.setAlpha(0f);
                view.setTranslationY(34f);
                view.animate().alpha(1f).translationY(0f).setDuration(560).setStartDelay(delay).start();
                delay += 110;
            }
        }
    }

    private void setKeyTimeUnavailable() {
        if (daysValue != null) daysValue.setText("--");
        if (hoursValue != null) hoursValue.setText("--");
        if (minutesValue != null) minutesValue.setText("--");
        if (secondsValue != null) secondsValue.setText("--");
    }

    private void startKeyCountdown() {
        final String expiry = exdate();
        if (expiry == null || expiry.trim().isEmpty() || "NULL".equalsIgnoreCase(expiry.trim())) {
            if (expiryValue != null) expiryValue.setText("Lifetime");
            if (timeRemaining != null) timeRemaining.setText("Lifetime");
            return;
        }

        final long expiryMillis = parseExpiryMillis(expiry.trim());
        if (expiryValue != null) {
            if (expiryMillis > 0L) {
                expiryValue.setText(new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                        .format(new Date(expiryMillis)));
            } else {
                expiryValue.setText(expiry.trim());
            }
        }
        if (expiryMillis <= 0L) {
            if (timeRemaining != null) timeRemaining.setText("--");
            return;
        }

        final Handler timerHandler = new Handler(getMainLooper());
        final Runnable timer = new Runnable() {
            @Override public void run() {
                long remaining = expiryMillis - System.currentTimeMillis();
                if (remaining <= 0L) {
                    setTimeValues(0, 0, 0, 0);
                    if (subscriptionStatus != null) {
                        subscriptionStatus.setText("Expired");
                        subscriptionStatus.setTextColor(Color.parseColor("#FF5252"));
                    }
                    if (timeRemaining != null) timeRemaining.setText("Expired");
                    return;
                }
                if (subscriptionStatus != null) {
                    subscriptionStatus.setText("Active");
                    subscriptionStatus.setTextColor(Color.parseColor("#25C779"));
                }
                long totalSeconds = TimeUnit.MILLISECONDS.toSeconds(remaining);
                long days = totalSeconds / 86400L;
                long hours = (totalSeconds % 86400L) / 3600L;
                long minutes = (totalSeconds % 3600L) / 60L;
                long seconds = totalSeconds % 60L;
                setTimeValues(days, hours, minutes, seconds);
                timerHandler.postDelayed(this, 1000L);
            }
        };
        timer.run();
    }

    private long parseExpiryMillis(String value) {
        try {
            long numeric = Long.parseLong(value);
            return numeric < 100000000000L ? numeric * 1000L : numeric;
        } catch (NumberFormatException ignored) {}

        String[] formats = {"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
                "dd-MM-yyyy HH:mm:ss", "dd/MM/yyyy HH:mm:ss", "MMM dd, yyyy HH:mm:ss"};
        for (String format : formats) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(format, Locale.US);
                parser.setLenient(false);
                Date parsed = parser.parse(value);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) {}
        }
        return -1L;
    }

    @SuppressLint("SetTextI18n")
    private void setTimeValues(long days, long hours, long minutes, long seconds) {
        if (daysValue != null) daysValue.setText(String.format(Locale.US, "%02d", days));
        if (hoursValue != null) hoursValue.setText(String.format(Locale.US, "%02d", hours));
        if (minutesValue != null) minutesValue.setText(String.format(Locale.US, "%02d", minutes));
        if (secondsValue != null) secondsValue.setText(String.format(Locale.US, "%02d", seconds));
        if (timeRemaining != null) {
            timeRemaining.setText(String.format(Locale.US, "%dd %02dh %02dm", days, hours, minutes));
        }
    }

    private void updateVersionDisplay() {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String localVersion = prefs.getString(PREF_VERSION_KEY, "1.2");
        if (appVersionText != null) {
            appVersionText.setText("Version " + localVersion);
        }
    }

    private void checkForRemoteUpdate() {
        new Downtwo(this, success -> {
            String remoteVersion = Downtwo.getLastServerVersion();
            if (remoteVersion == null || remoteVersion.trim().isEmpty()) return;

            SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String localVersion = prefs.getString(PREF_VERSION_KEY, "");
            File installedLoader = new File(getFilesDir(), "loader/libbgmi.so");

            if (!remoteVersion.equals(localVersion) && installedLoader.exists() && !isGameRunning) {
                isUpdateAvailable = true;
                updateButtonState(false);
                // Download the new GitHub build immediately; no data clearing or button press needed.
                startDownload();
            }
        }).execute(Downtwo.Link(), "check_only");
    }

    private void ensureGoogleServices() {
        if (googleServicesSetupRunning) return;

        if (GoogleServicesInstaller.isInstalled(this)) {
            new Thread(() -> MicroGInstaller.repairInternalInstall(getApplicationContext()),
                    "microg-repair").start();
            return;
        }

        googleServicesSetupRunning = true;
        runOnUiThread(() -> {
            if (downloadBox != null) downloadBox.setVisibility(View.VISIBLE);
            if (downloadStatusText != null) downloadStatusText.setText("Installing Google Services...");
            if (percentText != null) percentText.setText("0%");
            if (downloadProgressBar != null) {
                downloadProgressBar.setIndeterminate(false);
                downloadProgressBar.setMax(100);
                downloadProgressBar.setProgress(0);
            }
        });

        MicroGInstaller.installMicroGInBackground(this,
                (file, downloaded, total) -> {
                    if (total <= 0) return;
                    int percent = (int) Math.min(100, (downloaded * 100L) / total);
                    if (downloadProgressBar != null) downloadProgressBar.setProgress(percent);
                    if (percentText != null) percentText.setText(percent + "%");
                    if (downloadStatusText != null) downloadStatusText.setText("Installing " + file + "...");
                },
                result -> {
                    googleServicesSetupRunning = false;
                    new Thread(() -> {
                        boolean installed = GoogleServicesInstaller.isInstalled(getApplicationContext());
                        if (installed) {
                            MicroGInstaller.repairInternalInstall(getApplicationContext());
                        }
                        runOnUiThread(() -> {
                            if (downloadStatusText != null) {
                                downloadStatusText.setText(installed ? "Google Services ready" : result);
                            }
                            if (percentText != null) percentText.setText(installed ? "100%" : "FAILED");
                            if (downloadProgressBar != null) downloadProgressBar.setProgress(installed ? 100 : 0);
                            if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                        });
                    }, "microg-repair-after-install").start();
                });
    }

    private void showLicenseDetails() {
        SharedPreferences keyPrefs = getSharedPreferences("com.xlox.prefs", Context.MODE_PRIVATE);
        String key = keyPrefs.getString("USER", "Not available");
        String expiry = expiryValue == null ? "Unknown" : expiryValue.getText().toString();
        String remaining = timeRemaining == null ? "Unknown" : timeRemaining.getText().toString();
        String device = Build.MODEL == null ? "Android device" : Build.MODEL;
        String details = "Status: " + (subscriptionStatus == null ? "Unknown" : subscriptionStatus.getText())
                + "\n\nExpiry: " + expiry
                + "\nRemaining: " + remaining
                + "\nLicense key: " + key
                + "\nDevice: " + device;
        showInfoDialog("License Details", details);
    }

    private void showSettingsDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        panel.setPadding(pad, dp(4), pad, 0);
        TextView hint = new TextView(this);
        hint.setText("Move the slider to change settings");
        hint.setTextColor(Color.parseColor("#73777C"));
        hint.setTextSize(13);
        panel.addView(hint);

        addSliderSetting(panel, "1. Text size", "text_size", new String[]{"Small", "Normal", "Large"}, 1, p -> applyTextSize(12f + (p * 3f)));
        int[] textColors = {Color.BLACK, Color.parseColor("#27384D"), Color.parseColor("#E77700"), Color.parseColor("#18A558"), Color.WHITE};
        addSliderSetting(panel, "2. Text color", "text_color", new String[]{"Black", "Navy", "Orange", "Green", "White"}, 1, p -> applyTextTheme(textColors[p]));
        int[] backgroundColors = {Color.BLACK, Color.WHITE, Color.parseColor("#E8F1FF"), Color.parseColor("#FFE8E8"), Color.parseColor("#FFF4C2"), Color.parseColor("#FFF9EF")};
        addSliderSetting(panel, "3. Background color", "background_color", new String[]{"Black", "White", "Blue", "Red", "Yellow", "Cream"}, 1, p -> applyTheme(backgroundColors[p], getSavedTextColor()));
        String[] languages = {"English", "Hindi", "Urdu", "Bengali", "Punjabi", "Tamil", "Telugu"};
        addSliderSetting(panel, "4. Language", "language", languages, 0, p -> {
            setLanguageIndex(p);
        });
        int[] buttonColors = {Color.parseColor("#FF7A00"), Color.parseColor("#2979FF"), Color.parseColor("#18A558"), Color.parseColor("#E54848"), Color.parseColor("#8E44AD"), Color.parseColor("#E91E63"), Color.parseColor("#F4C430")};
        addSliderSetting(panel, "5. Button color", "button_color", new String[]{"Orange", "Blue", "Green", "Red", "Purple", "Pink", "Yellow"}, 0, p -> applyButtonColor(buttonColors[p]));

        new AlertDialog.Builder(this).setTitle("Settings").setView(panel).setNegativeButton("Close", null).show();
    }

    private interface SliderAction { void apply(int position); }

    private void addSliderSetting(LinearLayout panel, String label, String prefKey, String[] values, int initial, SliderAction action) {
        SharedPreferences sliderPrefs = getSharedPreferences("fxc.settings", Context.MODE_PRIVATE);
        initial = Math.max(0, Math.min(values.length - 1, sliderPrefs.getInt(prefKey, initial)));
        TextView title = settingSectionTitle(label);
        panel.addView(title);
        TextView current = new TextView(this);
        current.setText(values[initial]);
        current.setTextColor(Color.parseColor("#E77700"));
        current.setTextSize(13);
        current.setGravity(android.view.Gravity.END);
        panel.addView(current, new LinearLayout.LayoutParams(-1, dp(24)));
        android.widget.SeekBar slider = new android.widget.SeekBar(this);
        slider.setMax(values.length - 1);
        slider.setProgress(initial);
        slider.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_track));
        slider.setThumb(getResources().getDrawable(R.drawable.seekbar_thumb));
        slider.setPadding(dp(10), 0, dp(10), 0);
        slider.setSplitTrack(false);
        slider.setThumbOffset(dp(11));
        slider.setMinHeight(dp(42));
        slider.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                current.setText(values[progress]);
                getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit().putInt(prefKey, progress).apply();
                action.apply(progress);
            }
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) { }
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) { }
        });
        panel.addView(slider, new LinearLayout.LayoutParams(-1, dp(38)));
    }

    private int getSavedTextColor() {
        return getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).getInt("text", Color.parseColor("#27384D"));
    }

    private void applyTextSize(float sizeSp) {
        getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit().putFloat("textSize", sizeSp).apply();
        View root = findViewById(R.id.mainContainer);
        applyTextSizeToView(root, sizeSp);
    }

    private void applyTextSizeToView(View view, float sizeSp) {
        if (view instanceof TextView && view != startBgmi) ((TextView) view).setTextSize(sizeSp);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTextSizeToView(group.getChildAt(i), sizeSp);
        }
    }

    private void addLiveColorWatcher(android.widget.EditText field, int target, TextView preview) {
        field.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    int color = Color.parseColor(s.toString().trim());
                    preview.setBackgroundColor(color);
                    preview.setTextColor(luminance(color) < 140 ? Color.WHITE : Color.BLACK);
                    if (target == 0) {
                        View root = findViewById(R.id.mainContainer);
                        if (root != null) root.setBackgroundColor(color);
                        getWindow().setStatusBarColor(color);
                        getWindow().setNavigationBarColor(color);
                    } else if (target == 1) {
                        applyTextTheme(color);
                    } else {
                        applyButtonColor(color);
                    }
                } catch (IllegalArgumentException ignored) { }
            }
            public void afterTextChanged(android.text.Editable e) { }
        });
    }

    private int luminance(int color) {
        return (int) (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
    }

    private void applyButtonColor(int color) {
        getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit().putInt("button", color).apply();
        if (startBgmi != null) {
            if (color == Color.parseColor("#F21721")) {
                startBgmi.setBackgroundResource(R.drawable.bg_launch_red);
            } else {
                android.graphics.drawable.GradientDrawable button = new android.graphics.drawable.GradientDrawable();
                button.setColor(color);
                button.setCornerRadius(dp(19));
                startBgmi.setBackground(button);
            }
        }
    }

    private TextView settingSectionTitle(String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextColor(Color.parseColor("#E77700"));
        title.setTextSize(14);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(14), 0, dp(5));
        return title;
    }

    private Button settingButton(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setOnClickListener(listener);
        button.setMinHeight(dp(42));
        return button;
    }

    private void applySavedTheme() {
        SharedPreferences prefs = getSharedPreferences("fxc.settings", Context.MODE_PRIVATE);
        int bg = prefs.getInt("background", Color.BLACK);
        int text = prefs.getInt("text", Color.parseColor("#E8EDF7"));
        int button = Color.parseColor("#F21721");
        if (bg == Color.WHITE) bg = Color.BLACK;
        if (text == Color.parseColor("#27384D")) text = Color.parseColor("#E8EDF7");
        if (button == Color.parseColor("#FF7A00")) button = Color.parseColor("#FF8500");
        applyTheme(bg, text);
        applyButtonColor(button);
        int languageIndex = prefs.getInt("language", prefs.getBoolean("hindi", false) ? 1 : 0);
        setLanguageIndex(Math.max(0, Math.min(6, languageIndex)));
    }

    private void applyTheme(int background, int text) {
        getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit()
                .putInt("background", background).putInt("text", text).apply();
        View root = findViewById(R.id.mainContainer);
        if (root != null) root.setBackgroundColor(Color.TRANSPARENT);
        View content = findViewById(android.R.id.content);
        if (content != null) content.setBackgroundColor(Color.TRANSPARENT);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        if (startBgmi instanceof TextView) ((TextView) startBgmi).setTextColor(Color.WHITE);
    }

    private void applyTextTheme(int text) {
        getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit().putInt("text", text).apply();
        View root = findViewById(R.id.mainContainer);
        if (startBgmi instanceof TextView) ((TextView) startBgmi).setTextColor(Color.WHITE);
    }

    private void applyTextColor(View view, int color) {
        if (view == null) return;
        if (view instanceof TextView && view != startBgmi && view != startFB) {
            ((TextView) view).setTextColor(color);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTextColor(group.getChildAt(i), color);
        }
    }

    private void setLanguageIndex(int index) {
        getSharedPreferences("fxc.settings", Context.MODE_PRIVATE).edit()
                .putInt("language", index).putBoolean("hindi", index == 1).apply();
        View root = findViewById(R.id.mainContainer);
        if (root == null) return;
        String[][] labels = {
                {"Admin Panel", "एडमिन पैनल", "پنل ایڈمن", "অ্যাডমিন প্যানেল", "ਐਡਮਿਨ ਪੈਨਲ", "அட்மின் பேனல்", "అడ్మిన్ ప్యానల్"},
                {"License Overview", "लाइसेंस विवरण", "لائسنس کی تفصیل", "লাইসেন্স বিবরণ", "ਲਾਇਸੈਂਸ ਵੇਰਵਾ", "லைசென்ஸ் விவரம்", "లైసెన్స్ వివరాలు"},
                {"Status", "स्थिति", "حالت", "স্থিতি", "ਸਥਿਤੀ", "நிலை", "స్థితి"},
                {"Expiry", "समाप्ति", "میعاد", "মেয়াদ শেষ", "ਮਿਆਦ ਪੁੱਗਣੀ", "காலாவதி", "గడువు"},
                {"Remaining", "शेष समय", "باقی وقت", "অবশিষ্ট", "ਬਾਕੀ ਸਮਾਂ", "மீதமுள்ள", "మిగిలిన సమయం"},
                {"System", "सिस्टम", "سسٹم", "সিস্টেম", "ਸਿਸਟਮ", "சிஸ்டம்", "సిస్టమ్"},
                {"Ready to launch", "लॉन्च के लिए तैयार", "لانچ کے لیے تیار", "লঞ্চের জন্য প্রস্তুত", "ਲਾਂਚ ਲਈ ਤਿਆਰ", "லாஞ்ச் செய்ய தயார்", "లాంచ్ చేయడానికి సిద్ధంగా ఉంది"},
                {"Settings", "सेटिंग्स", "ترتیبات", "সেটিংস", "ਸੈਟਿੰਗਾਂ", "அமைப்புகள்", "సెట్టింగ్‌లు"},
                {"Logs", "लॉग्स", "لاگز", "লগ", "ਲਾਗ", "பதிவுகள்", "లాగ్‌లు"},
                {"Check Update", "अपडेट जांचें", "اپ ڈیٹ چیک کریں", "আপডেট দেখুন", "ਅੱਪਡੇਟ ਜਾਂਚੋ", "புதுப்பிப்பை சரிபார்க்கவும்", "అప్‌డేట్ తనిఖీ చేయండి"},
                {"Logout", "लॉगआउट", "لاگ آؤٹ", "লগআউট", "ਲੌਗਆਉਟ", "வெளியேறு", "లాగ్ అవుట్"},
                {"Facebook login repair", "Facebook लॉगिन सुधार", "Facebook لاگ ان مرمت", "Facebook লগইন মেরামত", "Facebook ਲਾਗਇਨ ਮੁਰੰਮਤ", "Facebook உள்நுழைவு சரிசெய்தல்", "Facebook లాగిన్ రిపేర్"},
                {"Active", "सक्रिय", "فعال", "সক্রিয়", "ਕਿਰਿਆਸ਼ੀਲ", "செயலில்", "యాక్టివ్"},
                {"Lifetime", "आजीवन", "تاحیات", "আজীবন", "ਜੀਵਨ ਭਰ", "வாழ்நாள்", "లైఫ్‌టైమ్"},
                {"Online", "ऑनलाइन", "آن لائن", "অনলাইন", "ਆਨਲਾਈਨ", "ஆன்லைன்", "ఆన్‌లైన్"}
        };
        translateView(root, labels, index);
    }

    private void translateView(View view, String[][] labels, int languageIndex) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            String current = text.getText().toString();
            for (String[] row : labels) {
                for (String languageValue : row) {
                    if (current.equals(languageValue)) {
                        text.setText(row[Math.max(0, Math.min(languageIndex, row.length - 1))]);
                        break;
                    }
                }
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) translateView(group.getChildAt(i), labels, languageIndex);
        }
    }

    private void showInfoDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    private void logoutUser() {
        getSharedPreferences("com.xlox.prefs", Context.MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, LogAct.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void startWorkflow() {
        runOnUiThread(() -> {
            if (downloadBox != null) downloadBox.setVisibility(View.GONE);
            if (restartButton != null) restartButton.setVisibility(View.GONE);
            if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
        });
        isUpdateAvailable = false;
    }

    private void startDownload() {
        runOnUiThread(() -> {
            if (downloadBox != null) downloadBox.setVisibility(View.VISIBLE);
            setLaunchButtonText("UPDATING...");
            if (downloadStatusText != null) downloadStatusText.setText("Preparing process...");
            if (percentText != null) percentText.setText("0%");
            if (downloadProgressBar != null) {
                downloadProgressBar.setIndeterminate(false);
                downloadProgressBar.setMax(100);
                downloadProgressBar.setProgress(0);
            }
            if (restartButton != null) restartButton.setVisibility(View.GONE);
            if (loadingCursor != null) loadingCursor.setVisibility(View.VISIBLE);
        });

        Downtwo task = new Downtwo(this, success -> {
            if (success) {
                runOnUiThread(() -> {
                    isUpdateAvailable = false;
                    if (downloadStatusText != null) downloadStatusText.setText("All process done");
                    if (percentText != null) percentText.setText("100%");
                    if (downloadProgressBar != null) downloadProgressBar.setProgress(100);
                    if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                    
                    updateVersionDisplay(); // Refresh version text after update
                    setLaunchButtonText(isGameInstalled ? "LAUNCH GAME" : "INSTALL GAME");
                    
                    if (restartButton != null) {
                        restartButton.setVisibility(View.VISIBLE);
                        restartButton.setAlpha(0f);
                        restartButton.animate().alpha(1f).setDuration(500).start();
                    }
                });
            } else {
                runOnUiThread(() -> {
                    // Keep update failures silent instead of showing a popup/toast.
                    isUpdateAvailable = false;
                    if (downloadBox != null) downloadBox.setVisibility(View.GONE);
                    if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                    setLaunchButtonText(isGameInstalled ? "LAUNCH GAME" : "INSTALL GAME");
                });
            }
        });

        task.setProgressListener(progress -> runOnUiThread(() -> {
            if (downloadProgressBar != null) {
                downloadProgressBar.setIndeterminate(false);
                downloadProgressBar.setMax(100);
                downloadProgressBar.setProgress(progress);
            }
            if (percentText != null) percentText.setText(progress + "%");
            if (downloadStatusText != null) downloadStatusText.setText("Preparing process...");
        }));
        
        task.execute(Downtwo.Link());
    }

    private void restartApp() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            Runtime.getRuntime().exit(0);
        }
    }

    private void checkObbApplied() {
        new Thread(() -> {
            try {
                PackageInfo info = getPackageManager().getPackageInfo(PKG_BGMI, 0);
                String gameObb = "main." + info.versionCode + "." + PKG_BGMI + ".obb";
                String destPath = MetaStorageManager.obtainAppExternalStorageDir(PKG_BGMI) + "/Android/obb/" + PKG_BGMI;
                File destFile = new File(destPath, gameObb);
                if (destFile.exists()) {
                    isObbCopied = true;
                    runOnUiThread(() -> { if (obbButton != null) obbButton.setVisibility(View.GONE); });
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void updateGameStatus() {
        isGameInstalled = false;
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(PKG_BGMI, 0);
            if (packageInfo != null) {
                isGameInstalled = true;
                if (gameName != null) gameName.setText("BATTLEGROUNDS INDIA");
                if (packageName != null) packageName.setText("COM.PUBG.IMOBILE");
                if (gameStatus != null) gameStatus.setText("SAFE");
                if (deviceStatus != null) {
                    deviceStatus.setText("Safe");
                    deviceStatus.setTextColor(Color.parseColor("#315FE5"));
                }
                updateButtonState(false);
            }
        } catch (Exception ignored) {
            isGameInstalled = false;
            if (gameStatus != null) gameStatus.setText("Not Installed");
            if (deviceStatus != null) {
                deviceStatus.setText("Not installed");
                deviceStatus.setTextColor(Color.parseColor("#FF9800"));
            }
            setLaunchButtonText("INSTALL GAME");
            if (startText != null) {
                startText.setText("INSTALL GAME");
                startText.setTextColor(Color.parseColor("#FF8C00"));
            }
            if (actionIcon != null) {
                actionIcon.setImageResource(android.R.drawable.ic_menu_save);
                actionIcon.setColorFilter(Color.parseColor("#FF8C00"));
            }
        }
    }

    private void setLaunchButtonText(String label) {
        if (startText != null) startText.setText(label);
        if (startBgmi instanceof Button) {
            Button button = (Button) startBgmi;
            button.setText(label);
            button.setGravity(android.view.Gravity.CENTER);
            button.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateButtonState(boolean running) {
        isGameRunning = running;
        runOnUiThread(() -> {
            if (running) {
                setLaunchButtonText("STOP GAME");
                if (startText != null) {
                    startText.setText("STOP GAME");
                    startText.setTextColor(Color.parseColor("#FF4444"));
                }
                if (actionIcon != null) {
                    actionIcon.setImageResource(android.R.drawable.ic_delete);
                    actionIcon.setColorFilter(Color.parseColor("#FF4444"));
                }
                if (startBgmi != null) {
                    startBgmi.setBackgroundResource(R.drawable.bg_stop_button);
                }
                if (downloadBox != null) {
                    downloadBox.setVisibility(View.VISIBLE);
                    if (downloadStatusText != null) downloadStatusText.setText("Game Running...");
                    if (percentText != null) percentText.setText("ACTIVE");
                    if (downloadProgressBar != null) {
                        downloadProgressBar.setIndeterminate(true);
                        downloadProgressBar.setProgress(100);
                    }
                    if (restartButton != null) restartButton.setVisibility(View.GONE);
                }
            } else {
                if (isUpdateAvailable) {
                    setLaunchButtonText("UPDATE AVAILABLE");
                    if (startText != null) {
                        startText.setText("UPDATE AVAILABLE");
                        startText.setTextColor(Color.parseColor("#FF8C00"));
                    }
                } else {
                    setLaunchButtonText("LAUNCH GAME");
                    if (startText != null) {
                        startText.setText("LAUNCH");
                        startText.setTextColor(Color.parseColor("#FF8C00"));
                    }
                }
                if (actionIcon != null) {
                    actionIcon.setImageResource(android.R.drawable.ic_media_play);
                    actionIcon.setColorFilter(Color.parseColor("#FF8C00"));
                }
                if (startBgmi != null) {
                    startBgmi.setBackgroundResource(R.drawable.bg_launch_red);
                }
                if (downloadBox != null) {
                    new Handler().postDelayed(() -> {
                        if (!isGameRunning && !isUpdateAvailable) downloadBox.setVisibility(View.GONE);
                    }, 1000);
                }
            }
        });
    }

    private void handleLaunchFlow() {
        try {
            if (!MetaActivationManager.getActivationStatus()) {
                showStatusToggle("LAUNCHING FAILED", true);
                return;
            }
        } catch (Exception ignored) {
            showStatusToggle("LAUNCHING FAILED", true);
            return;
        }

        File libFile = new File(getFilesDir(), "loader/libbgmi.so");
        if (!libFile.exists()) {
            startDownload();
            return;
        }

        if (!isObbCopied) {
            copyObbFiles();
        } else {
            showStatusToggle("LAUNCHING BGMI", false);
            new Handler().postDelayed(() -> {
                hideStatusToggle();
                launchGame();
            }, 2500);
        }
    }

    private void showStatusToggle(String message, boolean isError) {
        if (statusToggle == null) return;
        
        runOnUiThread(() -> {
            statusToggle.setVisibility(View.VISIBLE);
            statusToggle.setAlpha(0f);
            statusToggle.animate().alpha(1f).setDuration(300).start();
            
            if (statusToggleText != null) {
                statusToggleText.setText(message);
                statusToggleText.setTextColor(isError ? Color.parseColor("#B3261E") : Color.parseColor("#4A260E"));
            }
            
            if (statusLoader != null) {
                statusLoader.setVisibility(isError ? View.GONE : View.VISIBLE);
            }
            
            if (statusErrorIcon != null) {
                statusErrorIcon.setVisibility(isError ? View.VISIBLE : View.GONE);
            }
            
            if (isError) {
                new Handler().postDelayed(this::hideStatusToggle, 3000);
            }
        });
    }

    private void hideStatusToggle() {
        if (statusToggle == null) return;
        
        runOnUiThread(() -> {
            statusToggle.animate().alpha(0f).setDuration(300).withEndAction(() -> {
                statusToggle.setVisibility(View.GONE);
            }).start();
        });
    }

    private void launchGame() {
        try {
            Intent intent = MetaActivityManager.obtainSplashLaunchIntent(PKG_BGMI, this);
            if (intent != null) {
                startActivity(intent);
                updateButtonState(true);
            }
        } catch (Exception e) {
            Log.e("MAct", "Launch error", e);
        }
    }

    private void stopGame() {
        try {
            MetaActivityManager.killAppByPkg(PKG_BGMI);
            updateButtonState(false);
        } catch (Exception e) {
            Toast.makeText(this, "Stop Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void installGame() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("market://details?id=" + PKG_BGMI));
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + PKG_BGMI));
            startActivity(intent);
        }
    }

    private void openExternalUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Log.e("MAct", "Unable to open social link", e);
        }
    }

    private void copyObbFiles() {
        if (obbButton == null) return;
        
        Button btn = (Button) obbButton;
        btn.setEnabled(false);
        if (downloadBox != null) downloadBox.setVisibility(View.VISIBLE);
        if (downloadStatusText != null) downloadStatusText.setText("Preparing process...");
        if (percentText != null) percentText.setText("0%");
        if (downloadProgressBar != null) {
            downloadProgressBar.setIndeterminate(false);
            downloadProgressBar.setMax(100);
            downloadProgressBar.setProgress(0);
        }
        
        AppManager appManager = new AppManager(this);
        appManager.copyObbFolderAsync(PKG_BGMI, new AppManager.CopyCallback() {
            @Override
            public void onCopyCompleted(boolean success) {
                runOnUiThread(() -> {
                    if (success) {
                        isObbCopied = true;
                        btn.setVisibility(View.GONE);
                        if (downloadStatusText != null) downloadStatusText.setText("Facebook access ready");
                        if (percentText != null) percentText.setText("100%");
                        if (downloadProgressBar != null) downloadProgressBar.setProgress(100);
                        new Handler().postDelayed(() -> {
                            if (downloadBox != null) downloadBox.setVisibility(View.GONE);
                        }, 900);
                        Toast.makeText(MAct.this, "OBB Copied Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        btn.setEnabled(true);
                        btn.setText("APPLY OBB");
                        if (downloadBox != null) downloadBox.setVisibility(View.GONE);
                        Toast.makeText(MAct.this, "OBB Copy Failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onProgressUpdate(int progress) {
                runOnUiThread(() -> {
                    if (downloadStatusText != null) downloadStatusText.setText("Preparing process...");
                    if (percentText != null) percentText.setText(progress + "%");
                    if (downloadProgressBar != null) downloadProgressBar.setProgress(progress);
                });
            }
        }, false); // false to hide the default dialog
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
            }
        }
    }
}
