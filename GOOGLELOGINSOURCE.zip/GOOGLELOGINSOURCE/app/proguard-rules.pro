-keep class com.xlox.BoxApplication {*;}
-keep class com.xlox.utils.Prefs {*;}
-keep class com.xlox.Overlay {
    public <methods>;
}

-keep public class com.xlox.Overlay
-keep class com.xlox.LogAct { *; }
-keep class com.xlox.MAct { *; }
-keep class com.xlox.utils.Downtwo { *; }

# Production hardening: obfuscate/repackage classes not required by JNI, XML, or reflection.
-repackageclasses 'p'
-allowaccessmodification
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.xlox.ProAnimatedBackground { *; }
-keep class com.xlox.FacebookActivity { *; }
