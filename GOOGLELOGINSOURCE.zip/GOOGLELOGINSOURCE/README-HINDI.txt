KALI LOADER - DARK NEON UI UPDATE

Changes:
- Updated app/src/main/res/layout/activity_main.xml to a dark glass/neon orange layout.
- Preserved all 47 original view IDs in activity_main.xml so existing findViewById bindings/listeners remain connected.
- Updated the card, tile, status, icon, version-pill and launch-button drawable resources.
- Updated MAct.java system bar colors and default theme colors.
- Kept the existing animated background class and other application logic intact.

Build:
- Open this project folder in Android Studio and sync Gradle.
- Build > Make Project, or run ./gradlew :app:assembleDebug.
- A full Gradle build could not be completed in this environment because Gradle 8.5 must be downloaded and network access to services.gradle.org was unavailable.
- XML resources were parsed successfully and activity_main.xml drawable references were checked.
