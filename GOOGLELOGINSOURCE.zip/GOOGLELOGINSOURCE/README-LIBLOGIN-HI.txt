LIBLOGIN.SO - INTEGRATION NOTE

File added:
app/src/main/jniLibs/arm64-v8a/liblogin.so

Binary check:
- ELF 64-bit shared object
- ARM64 / AArch64
- Android API 21 target

IMPORTANT:
This source's existing Java classes load the native library named XloX.
The added liblogin.so exports JNI symbol:
Java_com_Thunder_project_NativeBridge_getSignature

The project currently has no matching Java class:
com.Thunder.project.NativeBridge
Therefore this library is packaged in the APK for ARM64 devices, but is NOT
loaded or called by app code. Loading/calling it without the matching JNI
class and method contract can cause UnsatisfiedLinkError or runtime failure.
No existing XloX native loading code was replaced.

To enable functionality, obtain the library's documented JNI API / matching
Java class from its publisher and verify its intended use and permissions.
This package step alone does not prove the library works.
